# joeprime
Function to evaluate whether an integer is a prime number.
